---
title: Overview
---

<!-- - [Redis in 1024 lines of code](redis-1k.html) -->
- [The Motivation behind writing](motivation.html)
- [Collection of interesting topics](ideas.html)

I craft these articles primarily for my own benefit. However, should you have any insights or feedback to share, please don't hesitate to <a href="mailto:mail@mlesniak.com">reach out to me via email</a>. Your thoughts are greatly appreciated.